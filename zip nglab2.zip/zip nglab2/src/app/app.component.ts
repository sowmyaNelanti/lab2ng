import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app works!';
  ID;
  UID;
  Name;
  UName;
  Salary;
  USalary;
  Department;
  UDepartment;
  gindex;
  statusString = "";
  tableData = [
    { empId: 1001, empName: "Rahul", empSal: 9000, empDep: "Java" },
    { empId: 1002, empName: "Sachin", empSal: 19000, empDep: "OraApps" },
    { empId: 1003, empName: "Vikash", empSal: 29000, empDep: "BI" },
  ];
  addemployee() {
    this.tableData.push({ empId: this.ID, empName: this.Name, empSal: this.Salary, empDep: this.Department});
    this.statusString = "Data inserted";
  }
  updateEmployee(row,index:number){
  this.UID=row.empId;
  this.UName=row.empName;
  this.USalary=row.empSal;
  this.UDepartment=row.empDep;
  this. gindex=index;
  }
  deleteEmployee(row,index:number){
this. tableData.splice(index, 1);
this.statusString = "Data deleted";
  }
   updateemployee()
 {
this.statusString = "Data updated";
this.tableData[this.gindex].empId=this.UID,
this.tableData[this.gindex].empName=this.UName,
this.tableData[this.gindex].empSal=this.USalary,
this.tableData[this.gindex].empDep= this.UDepartment
}
sortTable=[
                                  {empId1:1001,empName1:'Rahul',empSal1:9000,empDep1:'JAVA',empjoiningdate:'6/12/2014'},
                                  {empId1:1002,empName1:'Vikash',empSal1:11000,empDep1:'ORAAPS',empjoiningdate:'6/12/2017'},
                                  {empId1:1003,empName1:'Uma',empSal1:12000,empDep1:'JAVA',empjoiningdate:'6/12/2010'},
                                  {empId1:1004,empName1:'Sachin',empSal1:11500,empDep1:'ORAAPS',empjoiningdate:'11/12/2017'},
                                  {empId1:1005,empName1:'Amol',empSal1:7000,empDep1:'.NET',empjoiningdate:'1/1/2018'},
                                  {empId1:1006,empName1:'Vishal',empSal1:17000,empDep1:'BI',empjoiningdate:'9/12/2012'},
                                  {empId1:1007,empName1:'Rajita',empSal1:21000,empDep1:'BI',empjoiningdate:'6/7/2014'},
                                  {empId1:1008,empName1:'Neelima',empSal1:81000,empDep1:'TESTING',empjoiningdate:'6/17/2015'},
                                  {empId1:1009,empName1:'Daya',empSal1:1000,empDep1:'TESTING',empjoiningdate:'6/17/2016'}
                                   ];
                                    isDesc: boolean = false;
  column: string = 'CategoryName';
  sort(property){
    this.isDesc = !this.isDesc; //change the direction    
    this.column = property;
    let direction = this.isDesc ? 1 : -1;

    this.sortTable.sort(function(a, b){
        if(a[property] < b[property]){
            return -1 * direction;
        }
        else if( a[property] > b[property]){
            return 1 * direction;
        }
        else{
            return 0;
        }
    });
  }

}
